package com.example.android.movies;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by Abdulrhman on 20/10/2016.
 */
public class adapterMovie extends ArrayAdapter {

    public adapterMovie(Context context, List<ItemsClass> itemsArraylist) {
        super(context, 0,  itemsArraylist);

    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View rootview =convertView;
        if (rootview==null){
             rootview = LayoutInflater.from(getContext()).inflate(R.layout.item_layout,parent,false);
        }

        ItemsClass currentItem = (ItemsClass) getItem(position);

        ImageView poster = (ImageView) rootview.findViewById(R.id.poster);
        Picasso.with(getContext()).load(currentItem.getPoster());

        return rootview;

    }
}
