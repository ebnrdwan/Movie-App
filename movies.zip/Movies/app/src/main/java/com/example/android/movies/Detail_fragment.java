package com.example.android.movies;


import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.squareup.picasso.Picasso;


/**
 * A simple {@link Fragment} subclass.
 */
public class Detail_fragment extends Fragment {

    private Bitmap theposterImage;
    private String theposter;
    private String thetitle;
    private String theoverView;
    private String thereleaseDate;
    private double therating;
    private float rating ;


    public Detail_fragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.detail_fragment, container, false);

        Intent getdata = getActivity().getIntent();
        if (getdata != null && getdata.hasExtra("ItemObject")) {

            ItemsClass parelableItem = getdata.getParcelableExtra("ItemObject");
            thetitle = parelableItem.getTitle();
            theoverView = parelableItem.getOverview();
            thereleaseDate = parelableItem.getReleaseDate();
            therating =  parelableItem.getrating()/2;
            theposter = parelableItem.getPoster();
        }

        ImageView poster = (ImageView) rootView.findViewById(R.id.poster);
        Picasso.with(getContext()).load(theposter).into(poster);

        TextView title = (TextView) rootView.findViewById(R.id.movietitle);
        title.setText(thetitle);
        TextView releaseDate = (TextView) rootView.findViewById(R.id.releaseDate);
        releaseDate.setText(thereleaseDate);
        RatingBar ratingbar = (RatingBar) rootView.findViewById(R.id.ratingmovie);
        ratingbar.setRating((float) therating);

        TextView overivew = (TextView) rootView.findViewById(R.id.overivewmovie);
        overivew.setText(theoverView);


        return rootView;
    }

}
