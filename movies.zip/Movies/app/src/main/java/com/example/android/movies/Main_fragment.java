package com.example.android.movies;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;

import java.util.ArrayList;
import java.util.List;


public class Main_fragment extends Fragment implements LoaderManager.LoaderCallbacks<List<ItemsClass>> {

    public static final String BASE_MOVIE_URL = "http://api.themoviedb.org/3/movie/popular?api_key=5f7c26a298341681f7a738b181585c63";
    adapterMovie adapter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootview = inflater.inflate(R.layout.main_fragment, container, false);

//        List<ItemsClass>itemsClasses = new ArrayList<>();
//        itemsClasses.add(new ItemsClass("http://image.tmdb.org/t/p/w185//nBNZadXqJSdt05SHLqgT0HuC5Gm.jpg"));
//        itemsClasses.add(new ItemsClass("http://image.tmdb.org/t/p/w185//nBNZadXqJSdt05SHLqgT0HuC5Gm.jpg"));
//        itemsClasses.add(new ItemsClass("http://image.tmdb.org/t/p/w185//nBNZadXqJSdt05SHLqgT0HuC5Gm.jpg"));
//        itemsClasses.add(new ItemsClass("http://image.tmdb.org/t/p/w185//nBNZadXqJSdt05SHLqgT0HuC5Gm.jpg"));


        LoaderManager loaderManager = getLoaderManager();
        Log.d("DEBUG", " the  InitLoader  method is called");
        loaderManager.initLoader(1, null, this);

        GridView movieGrid = (GridView) rootview.findViewById(R.id.gridview);
        adapter = new adapterMovie(getActivity(), new ArrayList<ItemsClass>());
        movieGrid.setAdapter(adapter);
        return rootview;

    }


    @Override
    public android.support.v4.content.Loader<List<ItemsClass>> onCreateLoader(int i, Bundle bundle) {
//       Uri movieRequest = Uri.parse(BASE_MOVIE_URL).buildUpon()


        return new LoaderMovie(getActivity());
    }

    @Override
    public void onLoadFinished(Loader<List<ItemsClass>> loader, List<ItemsClass> itemsClasses) {
        adapter.clear();
        if (itemsClasses != null && !itemsClasses.isEmpty()) {
            adapter.addAll(itemsClasses);
        }

    }

    @Override
    public void onLoaderReset(Loader<List<ItemsClass>> loader) {
        adapter.clear();

    }


}
