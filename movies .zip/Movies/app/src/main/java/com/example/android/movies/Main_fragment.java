package com.example.android.movies;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;

import java.util.ArrayList;
import java.util.List;


public class Main_fragment extends Fragment implements LoaderManager.LoaderCallbacks<List<ItemsClass>> {


    public static final String BASE_MOVIE_URL = "http://api.themoviedb.org/3/movie/popular?api_key=5f7c26a298341681f7a738b181585c63";
    adapterMovie adapter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, final ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootview = inflater.inflate(R.layout.main_fragment, container, false);

        LoaderManager loaderManager = getLoaderManager();
        Log.d("DEBUG", " the  InitLoader  method is called");
        loaderManager.initLoader(1, null, this);

        GridView movieGrid = (GridView) rootview.findViewById(R.id.gridview);
        adapter = new adapterMovie(getActivity(), new ArrayList<ItemsClass>());
        movieGrid.setAdapter(adapter);

        movieGrid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                ItemsClass currentItem = (ItemsClass) adapter.getItem(i);
                Log.d("DEDE",currentItem.toString());
                Intent gridIntent = new Intent(getActivity(), DetailActivity.class)
                        .putExtra("ItemObject", currentItem);
                startActivity(gridIntent);
            }
        });
        return rootview;

    }


    @Override
    public android.support.v4.content.Loader<List<ItemsClass>> onCreateLoader(int i, Bundle bundle) {
//       Uri movieRequest = Uri.parse(BASE_MOVIE_URL).buildUpon()


        return new LoaderMovie(getActivity());
    }

    @Override
    public void onLoadFinished(Loader<List<ItemsClass>> loader, List<ItemsClass> itemsClasses) {
        adapter.clear();
        if (itemsClasses != null && !itemsClasses.isEmpty()) {
            adapter.addAll(itemsClasses);
        }

    }

    @Override
    public void onLoaderReset(Loader<List<ItemsClass>> loader) {
        adapter.clear();

    }


}
