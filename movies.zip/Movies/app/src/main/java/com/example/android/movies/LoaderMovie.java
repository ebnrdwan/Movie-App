package com.example.android.movies;

import android.support.v4.content.AsyncTaskLoader;
import android.content.Context;
import android.util.Log;

import java.util.List;

/**
 * Created by Abdulrhman on 20/10/2016.
 */
public class LoaderMovie extends AsyncTaskLoader<List<ItemsClass>> {
    String url ;
    public LoaderMovie(Context context,String url) {

        super(context);
        this.url=url;
    }

    @Override
    protected void onStartLoading() {
        super.onStartLoading();
        forceLoad();
        Log.d("LOG_TAG_CORRECT"," onStartLoading called");
    }

    @Override
    public List<ItemsClass> loadInBackground() {
        if (url==null){
            return null;
        }

        List<ItemsClass> movieList = NetworkingMovie.FetchData(url);
        return movieList;
    }
}































