package com.example.android.movies;

/**
 * Created by Abdulrhman on 20/10/2016.
 */
public class ItemsClass {

    private String poster ;
    private String title ;
    private int releaseDate ;
    private int rating ;
    private String overview ;

    public ItemsClass(String poster  , String overview, String title, int releaseDate, int rating) {
        this.poster = poster;
        this.title = title;
        this.releaseDate = releaseDate;
        this.rating = rating;
        this.overview = overview;
    }

    public ItemsClass(String poster) {
        this.poster = poster;
    }

    public String getPoster() {
        return poster;
    }

    public void setPoster(String poster) {
        this.poster = poster;
    }

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    public int getrating() {
        return rating;
    }

    public void setrating(int rating) {
        this.rating = rating;
    }

    public int getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(int releaseDate) {
        this.releaseDate = releaseDate;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
